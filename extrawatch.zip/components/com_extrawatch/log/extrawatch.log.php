<?php die('Restricted access'); ?>
