<?php

/**
 * ExtraWatch - A real-time ajax joomla monitor and live stats
 * @package ExtraWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt     GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined('_JEXEC') or die('Restricted access');
?>

<table cellspacing='0'>
    <tr>
        <td colspan='5'>
            <h3><?php echo _EW_STATS_TITLE . "&nbsp;"; echo($extraWatch->date->getWeekFromTimestamp($week * 3600 * 24 * 7)); ?>
                /<?php echo($extraWatch->date->getYearFromTimestamp($week * 3600 * 24 * 7)); ?>
                <?php echo $extraWatchHTML->renderOnlineHelp("visit-stats"); ?></h3>
        </td>
    </tr>
    <tr>
        <td colspan='5'>
            <table border='0'>
                <tr>
                    <td align='left' width='10%'><a href='javascript:setWeek(<?php echo($prevWeek);?>)'
                                                    id='visits_<?php echo($prevWeek);?>'>&lt;
                        <?php echo _EW_STATS_WEEK;?>
                        &nbsp;<?php echo $extraWatch->date->getWeekFromTimestamp($prevWeek * 3600 * 24 * 7);?>
                    </a></td>
                    <td align='left'><img
                        src='<?php echo $extraWatch->config->getLiveSiteWithSuffix(); ?>components/com_extrawatch/icons/calendar.gif'
                        border='0' align='center'/></td>
                    <td align='center' width='20%'>
                        <?php if (@$week != $thisWeek) {
                        ?>
                        <a href='javascript:setWeek(<?php echo($thisWeek);?>)'
                           id='visits_$thisWeek'><?php echo _EW_STATS_THIS_WEEK;?></a>
                        <?php
                    }
                        ?>
                    </td>
                    <td align='right'
                        width='10%'><?php if ($nextWeek <= $thisWeek) echo("<img src='" . $extraWatch->config->getLiveSiteWithSuffix() . "components/com_extrawatch/icons/calendar.gif' border='0' align='center' /></td><td width='20%' align='right'><a href='javascript:setWeek($nextWeek)' id='visits_$nextWeek'>" . _EW_STATS_WEEK . "&nbsp;" . $extraWatch->date->getWeekFromTimestamp($nextWeek * 3600 * 24 * 7) . "&gt;</a>"); ?></td>
                </tr>
            </table>
            <?php echo $extraWatchStatHTML->renderVisitsGraph($week); ?>
    <tr>
        <td colspan='4'>

            <table width='100%'>
                <tr>
                    <td align='center'
                        class='<?php echo $extraWatchStatHTML->renderTabClass("0", @ExtraWatchHelper::requestGet('tab'));?>'>
                        <?php echo $extraWatchStatHTML->renderSwitched("0", _EW_STATS_DAILY, @ExtraWatchHelper::requestGet('tab')); ?>
                    </td>
                    <td align='center'
                        class='<?php echo $extraWatchStatHTML->renderTabClass("1", @ExtraWatchHelper::requestGet('tab'));?>'>
                        <?php echo $extraWatchStatHTML->renderSwitched("1", _EW_STATS_ALL_TIME, @ExtraWatchHelper::requestGet('tab')); ?>
                    </td>
                    <td align='center' class='tab_none'>
                    </td>
                </tr>
            </table>

</table>
