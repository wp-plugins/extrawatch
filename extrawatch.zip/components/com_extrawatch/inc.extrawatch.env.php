<?php

require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "interface.extrawatch.env.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "interface.extrawatch.dbwrap.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "interface.extrawatch.setup.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "class.extrawatch.env.request.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "class.extrawatch.env.factory.php");

require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "joomla" . DS . "class.extrawatch.env.joomla.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "joomla" . DS . "class.extrawatch.db.joomla.php");

require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "wordpress" . DS . "class.extrawatch.env.wordpress.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "wordpress" . DS . "class.extrawatch.db.wordpress.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "wordpress" . DS . "class.extrawatch.setup.wordpress.php");

require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "nocms" . DS . "class.extrawatch.db.nocms.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "nocms" . DS . "class.extrawatch.env.nocms.php");

require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "drupal" . DS . "class.extrawatch.db.drupal.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_extrawatch" . DS . "env" . DS . "drupal" . DS . "class.extrawatch.env.drupal.php");

?>
